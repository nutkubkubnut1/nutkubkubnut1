'use strict';
// Minimal dependency-free WebSocket server connection (RFC 6455, text frames).
const crypto = require('crypto');
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_PAYLOAD = 16 * 1024;     // client messages are tiny
const MAX_BUFFERED = 2 * 1024 * 1024; // drop very slow clients

class WSConn {
  constructor(sock) {
    this.sock = sock;
    this.buf = Buffer.alloc(0);
    this.frag = '';
    this.open = true;
    this.onmessage = null;
    this.onclose = null;
    sock.setNoDelay(true);
    sock.on('data', d => this._data(d));
    sock.on('close', () => this._closed());
    sock.on('error', () => this._closed());
  }
  _closed() {
    if (!this.open) return;
    this.open = false;
    try { this.sock.destroy(); } catch (e) {}
    if (this.onclose) this.onclose();
  }
  _data(d) {
    this.buf = this.buf.length ? Buffer.concat([this.buf, d]) : d;
    while (this.open) {
      const b = this.buf;
      if (b.length < 2) return;
      const fin = b[0] & 0x80, op = b[0] & 0x0f, masked = b[1] & 0x80;
      let len = b[1] & 0x7f, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; if (b.readUInt32BE(2)) { this.close(1009); return; } len = b.readUInt32BE(6); off = 10; }
      if (len > MAX_PAYLOAD) { this.close(1009); return; }
      if (!masked) { this.close(1002); return; }
      if (b.length < off + 4 + len) return;
      const mask = b.subarray(off, off + 4); off += 4;
      const pl = Buffer.allocUnsafe(len);
      for (let i = 0; i < len; i++) pl[i] = b[off + i] ^ mask[i & 3];
      this.buf = b.subarray(off + len);
      if (op === 8) { this.close(1000); return; }
      if (op === 9) { this._frame(10, pl); continue; }
      if (op === 10) continue;
      if (op === 1 || op === 0) {
        this.frag += pl.toString('utf8');
        if (this.frag.length > MAX_PAYLOAD) { this.close(1009); return; }
        if (!fin) continue;
        const txt = this.frag; this.frag = '';
        if (this.onmessage) { try { this.onmessage(txt); } catch (e) { console.error('ws message error', e); } }
      }
    }
  }
  _frame(op, pl) {
    if (!this.open) return;
    const len = pl.length;
    let h;
    if (len < 126) h = Buffer.from([0x80 | op, len]);
    else if (len < 65536) { h = Buffer.alloc(4); h[0] = 0x80 | op; h[1] = 126; h.writeUInt16BE(len, 2); }
    else { h = Buffer.alloc(10); h[0] = 0x80 | op; h[1] = 127; h.writeUInt32BE(0, 2); h.writeUInt32BE(len, 6); }
    if (this.sock.writableLength > MAX_BUFFERED) { this._closed(); return; }
    try { this.sock.write(Buffer.concat([h, pl])); } catch (e) { this._closed(); }
  }
  send(str) { this._frame(1, Buffer.from(str, 'utf8')); }
  close(code) {
    if (!this.open) return;
    try { const p = Buffer.alloc(2); p.writeUInt16BE(code || 1000); this._frame(8, p); this.sock.end(); } catch (e) {}
    this._closed();
  }
}

function acceptUpgrade(req, sock) {
  const key = req.headers['sec-websocket-key'];
  if (!key || String(req.headers.upgrade || '').toLowerCase() !== 'websocket') { sock.destroy(); return null; }
  const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  return new WSConn(sock);
}

module.exports = { acceptUpgrade };
