'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');
const db = require('./db');
const game = require('./game');
const { acceptUpgrade } = require('./ws');

const PORT = +process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, '..', 'public');
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.json': 'application/json', '.webmanifest': 'application/manifest+json' };

// simple per-IP rate limit for login/register
const hits = new Map();
function limited(ip, max, winMs) {
  const now = Date.now(); let h = hits.get(ip);
  if (!h || h.reset < now) { h = { n: 0, reset: now + winMs }; hits.set(ip, h); }
  h.n++; return h.n > max;
}
setInterval(() => { const now = Date.now(); for (const [k, h] of hits) if (h.reset < now) hits.delete(k); }, 60000).unref();
const ipOf = req => String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();

function json(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}
function readBody(req) {
  return new Promise((resolve) => {
    let s = '';
    req.on('data', c => { s += c; if (s.length > 4096) { req.destroy(); resolve(null); } });
    req.on('end', () => { try { resolve(JSON.parse(s || '{}')); } catch (e) { resolve(null); } });
    req.on('error', () => resolve(null));
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;
  try {
    if (req.method === 'POST' && (p === '/api/register' || p === '/api/login')) {
      if (limited(ipOf(req), 30, 10 * 60 * 1000)) return json(res, 429, { err: 'ลองบ่อยเกินไป กรุณารอสักครู่' });
      const b = await readBody(req); if (!b) return json(res, 400, { err: 'ข้อมูลไม่ถูกต้อง' });
      const r = p === '/api/register' ? await db.register(b.id, b.pw) : await db.login(b.id, b.pw);
      return json(res, r.err ? 400 : 200, r);
    }
    if (req.method === 'POST' && p === '/api/logout') {
      const b = await readBody(req); if (b && b.token) db.revoke(String(b.token));
      return json(res, 200, { ok: true });
    }
    if (req.method === 'GET' && p === '/api/session') {
      const k = db.userByToken(url.searchParams.get('token'));
      if (!k) return json(res, 401, { err: 'session expired' });
      return json(res, 200, { ok: true, name: db.getUser(k).name });
    }
    if (req.method === 'GET' && p === '/api/status') return json(res, 200, { ok: true, online: game.online() });
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    // static files
    let file = path.normalize(path.join(PUBLIC, p === '/' ? 'index.html' : decodeURIComponent(p)));
    if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end(); }
    fs.stat(file, (err, st) => {
      if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
      res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache',
        'X-Content-Type-Options': 'nosniff' });
      if (req.method === 'HEAD') return res.end();
      fs.createReadStream(file).pipe(res);
    });
  } catch (e) { console.error(e); json(res, 500, { err: 'server error' }); }
});

server.on('upgrade', (req, sock) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname !== '/ws') { sock.destroy(); return; }
  const key = db.userByToken(url.searchParams.get('token'));
  if (!key) { sock.write('HTTP/1.1 401 Unauthorized\r\n\r\n'); sock.destroy(); return; }
  const ws = acceptUpgrade(req, sock); if (!ws) return;
  const player = game.addPlayer(key, ws);
  ws.onmessage = txt => game.handle(player, txt);
  ws.onclose = () => game.removePlayer(player);
});

game.start();
server.listen(PORT, () => console.log(`ดาบแห่งป่าลึก online server: http://localhost:${PORT}  (data: ${db.DIR})`));

function shutdown() { console.log('saving…'); game.saveAll(); db.flush(); process.exit(0); }
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
