'use strict';
// Authoritative world simulation: monsters, combat, XP, boss, chat.
const S = require('../public/shared.js');
const db = require('./db');
const { hyp, clamp, TAU, ET, CX, CY, SAFE, T, WORLD, BOSS_POS, blocked, collideEnt, lvAt, dAt, MON_ORDER, xpNeed, stats, CD, SPEED, inSafe } = S;
const rnd = Math.random;
const TI = Object.fromEntries(MON_ORDER.map((t, i) => [t, i]));

const TICK = 50;               // ms (20 Hz)
const VIEW = 1100;             // interest radius for snapshots / events
const PACKS = 22;
const RESPAWN = [3.5, 5.5];

let nextId = 1;
const enemies = [], packs = [], respawnQ = [], projs = [];
const players = new Map();     // userKey -> player
let events = [];               // world events this tick
let time = 0;

/* ---------------- monsters ---------------- */
function mkEnemy(type, x, y, lv, pack) {
  const b = ET[type]; lv = lv || b.lv[0];
  const hp = Math.round(b.hp * (20 + 15 * lv));
  return { id: nextId++, type, kind: b.kind, big: !!b.big, x, y, hx: pack ? pack.x : x, hy: pack ? pack.y : y, r: b.r, hp, max: hp,
    dmg: Math.round(b.dmg * (6 + 2.8 * lv)), spd: b.spd, xp: Math.round((6 + 4.2 * lv) * (b.big ? 12 : b.hp)),
    gold: Math.round((1 + lv * 1.3) * (b.big ? 15 : 1)), lv, pack: pack || null, tgt: null, contrib: new Map(),
    t: rnd() * 5, face: 1, kx: 0, ky: 0, flash: 0, cd: 1, wind: 0, dash: 0, dvx: 0, dvy: 0, hit: false, wx: 0, wy: 0, wt: rnd() * 2,
    slam: 3, slamming: false, slamR: 0, spawn: 0 };
}
function nearPlayer(x, y, r) { for (const p of players.values()) if (hyp(p.x - x, p.y - y) < r) return true; return false; }
function spawnPack(dMin, dMax) {
  for (let i = 0; i < 80; i++) {
    let x, y;
    if (dMax) { const a = rnd() * TAU, r = dMin + (dMax - dMin) * Math.sqrt(rnd()); x = CX + Math.cos(a) * r; y = CY + Math.sin(a) * r; }
    else { x = T * 3 + rnd() * (WORLD - 6 * T); y = T * 3 + rnd() * (WORLD - 6 * T); }
    const d = hyp(x - CX, y - CY);
    if (d < SAFE + 90) continue;
    if (hyp(x - BOSS_POS.x, y - BOSS_POS.y) < 300) continue;
    if (blocked(x, y, 26)) continue;
    if (packs.some(p => hyp(p.x - x, p.y - y) < 230)) continue;
    const base = lvAt(d);
    const c = MON_ORDER.filter(t => t !== 'boss' && ET[t].lv[0] <= base && ET[t].lv[1] >= base);
    const type = c[rnd() * c.length | 0], b = ET[type];
    const n = b.kind === 'treant' ? 2 + (rnd() * 2 | 0) : 3 + (rnd() * 3 | 0);
    const p = { type, x, y, lo: 99, hi: 0, n };
    for (let j = 0; j < n; j++) {
      let ex = x, ey = y;
      for (let t = 0; t < 12; t++) { const a = rnd() * TAU, r = 22 + rnd() * 55; ex = x + Math.cos(a) * r; ey = y + Math.sin(a) * r; if (!blocked(ex, ey, b.r)) break; }
      const lv = clamp(base + Math.round(rnd() * 2 - 1), b.lv[0], b.lv[1]);
      p.lo = Math.min(p.lo, lv); p.hi = Math.max(p.hi, lv);
      enemies.push(mkEnemy(type, ex, ey, lv, p));
    }
    packs.push(p); return true;
  }
  return false;
}
function fillPacks() {
  const z1 = packs.filter(p => p.hi <= 5).length, z2 = packs.filter(p => p.lo >= 5 && p.hi <= 10).length;
  if (z1 < 6) return spawnPack(SAFE + 90, dAt(5.5));
  if (z2 < 5) return spawnPack(dAt(5.5), dAt(10.5));
  return spawnPack();
}
for (let i = 0; i < PACKS; i++) fillPacks();

const W = db.world();
let boss = mkEnemy('boss', BOSS_POS.x, BOSS_POS.y, 20, null);
if (Date.now() >= (W.bossAt || 0)) enemies.push(boss); else boss.hp = 0;

function alertPack(e, tgt) {
  if (!e.pack) return;
  for (const o of enemies) if (o.pack === e.pack && !o.tgt && hyp(o.x - e.x, o.y - e.y) < 280) o.tgt = tgt;
}

/* ---------------- players ---------------- */
function addPlayer(key, ws) {
  const u = db.getUser(key);
  const old = players.get(key);
  if (old) { send(old, { t: 'kick', m: 'บัญชีนี้ล็อกอินจากที่อื่น' }); old.ws.close(4000); removePlayer(old, true); }
  const sv = u.save || (u.save = { lvl: 1, xp: 0, gold: 0, pot: 3 });
  const p = { key, name: u.name, ws, x: CX + (rnd() - .5) * 80, y: CY + 70 + (rnd() - .5) * 40, dx: 0, dy: 1, face: 1, moving: 0,
    lvl: sv.lvl, xp: sv.xp, gold: sv.gold, pot: sv.pot, hp: 0, maxHp: 0, atk: 0, def: 0, dead: false, inv: 0, lastHurt: -99,
    lastAtk: 0, cd: { fire: 0, whirl: 0, heal: 0, pot: 0 }, spin: 0, spinTick: 0, lastMv: Date.now(), chatT: 0, q: [], r: 11 };
  Object.assign(p, stats(p.lvl)); p.hp = p.maxHp;
  players.set(key, p);
  send(p, { t: 'hi', id: key, name: p.name, x: p.x, y: p.y, bossAt: W.bossAt || 0, packs: packSummary() });
  ev({ k: 'jn', n: p.name });
  return p;
}
function persist(p) { const u = db.getUser(p.key); if (!u) return; u.save = { lvl: p.lvl, xp: p.xp, gold: p.gold, pot: p.pot }; db.markDirty(); }
function removePlayer(p, silent) {
  if (players.get(p.key) !== p) return;
  persist(p); players.delete(p.key);
  for (const e of enemies) if (e.tgt === p) e.tgt = null;
  if (!silent) ev({ k: 'lf', n: p.name });
}
function send(p, obj) { if (p.ws && p.ws.open) p.ws.send(JSON.stringify(obj)); }
function ev(e) { events.push(e); }
function priv(p, e) { p.q.push(e); }

function hurtPlayer(p, dmg, src) {
  if (p.inv > 0 || p.dead) return;
  dmg = Math.max(1, Math.round((dmg - p.def) * (.9 + rnd() * .2)));
  p.hp -= dmg; p.inv = .6; p.lastHurt = time;
  let kx = 0, ky = 0;
  if (src) { const dx = p.x - src.x, dy = p.y - src.y, d = hyp(dx, dy) || 1; kx = dx / d * 260; ky = dy / d * 260; }
  priv(p, { k: 'hu', v: dmg, kx, ky });
  ev({ k: 'ph', id: p.key, x: p.x, y: p.y, v: dmg });
  if (p.hp <= 0) { p.hp = 0; p.dead = true; for (const e of enemies) if (e.tgt === p) e.tgt = null; priv(p, { k: 'die' }); }
}
function gainXp(p, n) {
  p.xp += n;
  while (p.xp >= xpNeed(p.lvl)) {
    p.xp -= xpNeed(p.lvl); p.lvl++;
    Object.assign(p, stats(p.lvl)); p.hp = p.maxHp;
    ev({ k: 'lv', id: p.key, x: p.x, y: p.y, l: p.lvl });
  }
}

/* ---------------- combat ---------------- */
function hurtEnemy(e, dmg, kx, ky, kb, p) {
  if (e.hp <= 0 || e.spawn > 0) return;
  const crit = rnd() < .12; dmg = Math.round(dmg * (crit ? 1.8 : 1) * (.9 + rnd() * .2));
  e.hp -= dmg; e.flash = .12;
  if (p) { e.contrib.set(p.key, time); if (!e.tgt) { e.tgt = p; alertPack(e, p); } }
  const kres = e.big ? .15 : e.kind === 'treant' ? .5 : 1; e.kx += kx * kb * kres; e.ky += ky * kb * kres;
  if (e.wind > 0 && !e.big && crit) { e.wind = 0; e.slamming = false; }
  ev({ k: 'd', id: e.id, x: Math.round(e.x), y: Math.round(e.y - e.r * 2 - 6), v: dmg, c: crit ? 1 : 0, by: p ? p.key : '' });
  if (e.hp <= 0) killEnemy(e, p);
}
function killEnemy(e, killer) {
  ev({ k: 'kl', id: e.id, x: Math.round(e.x), y: Math.round(e.y), ti: TI[e.type] });
  for (const [k, t] of e.contrib) {
    const p = players.get(k); if (!p || p.dead || time - t > 20 || hyp(p.x - e.x, p.y - e.y) > 1300) continue;
    const xg = p.lvl - e.lv >= 6 ? Math.ceil(e.xp * .25) : e.xp;
    let g = 0, pot = 0;
    if (p === killer) { g = Math.round(e.gold * (.8 + rnd() * .4)); if (rnd() < (e.big ? 1 : .07)) pot = e.big ? 3 : 1; }
    p.gold += g; p.pot += pot; gainXp(p, xg);
    priv(p, { k: 'xp', v: xg, g, pt: pot, x: Math.round(e.x), y: Math.round(e.y - e.r * 2 - 24) });
    persist(p);
  }
  if (!e.big && e.pack) respawnQ.push({ p: e.pack, type: e.type, t: RESPAWN[0] + rnd() * (RESPAWN[1] - RESPAWN[0]) });
  if (e.big) { W.bossAt = Date.now() + S.BOSS_CD; db.markDirty(); ev({ k: 'bk', at: W.bossAt, by: killer ? killer.name : '' }); }
}
function onAttack(p, m) {
  if (p.dead) return;
  const now = time; if (now - p.lastAtk < .2) return; p.lastAtk = now;
  const c = clamp(m.c | 0, 0, 2);
  let dx = +m.dx || 0, dy = +m.dy || 0; const dl = hyp(dx, dy) || 1; dx /= dl; dy /= dl;
  p.dx = dx; p.dy = dy;
  const mul = [1, 1.1, 1.6][c], range = c === 2 ? 72 : 62;
  for (const e of enemies) {
    const ex = e.x - p.x, ey = e.y - p.y, d = hyp(ex, ey) || 1;
    if (d > range + e.r + 10) continue;
    const dot = (ex * dx + ey * dy) / d;
    if (dot > .3 || d < e.r + 20) hurtEnemy(e, p.atk * mul, ex / d, ey / d, c === 2 ? 380 : 200, p);
  }
  ev({ k: 'sw', id: p.key, x: Math.round(p.x), y: Math.round(p.y), c, dx: +dx.toFixed(2), dy: +dy.toFixed(2) });
}
function onSkill(p, m) {
  if (p.dead) return;
  const id = m.id; if (!(id in CD)) return;
  if (p.cd[id] > .15) return;
  if (id === 'pot') {
    if (p.pot <= 0 || p.hp >= p.maxHp) return;
    p.pot--; const h = Math.round(p.maxHp * .5); p.hp = Math.min(p.maxHp, p.hp + h); p.cd.pot = CD.pot;
    ev({ k: 'hl', id: p.key, x: Math.round(p.x), y: Math.round(p.y), v: h, pot: 1 }); persist(p); return;
  }
  p.cd[id] = CD[id];
  if (id === 'fire') {
    let dx = +m.dx || 0, dy = +m.dy || 0; const dl = hyp(dx, dy) || 1; dx /= dl; dy /= dl;
    const pr = { x: p.x + dx * 14, y: p.y - 16 + dy * 14, vx: dx * 480, vy: dy * 480, life: .9, dmg: p.atk * 1.9, owner: p };
    projs.push(pr); ev({ k: 'pr', x: Math.round(pr.x), y: Math.round(pr.y), vx: Math.round(pr.vx), vy: Math.round(pr.vy), id: p.key });
  }
  if (id === 'whirl') { p.spin = .7; p.spinTick = 0; ev({ k: 'sp', id: p.key, x: Math.round(p.x), y: Math.round(p.y) }); }
  if (id === 'heal') { const h = Math.round(p.maxHp * .4); p.hp = Math.min(p.maxHp, p.hp + h); ev({ k: 'hl', id: p.key, x: Math.round(p.x), y: Math.round(p.y), v: h }); }
}
function onMove(p, m) {
  if (p.dead) return;
  const now = Date.now(), dt = Math.min(1, (now - p.lastMv) / 1000); p.lastMv = now;
  const x = +m.x, y = +m.y; if (!isFinite(x) || !isFinite(y)) return;
  const maxd = SPEED * 1.35 * dt + 70;
  if (hyp(x - p.x, y - p.y) > maxd || x < T * .5 || y < T * .5 || x > WORLD - T * .5 || y > WORLD - T * .5) { priv(p, { k: 'pos', x: p.x, y: p.y }); return; }
  p.x = x; p.y = y;
  const dl = hyp(+m.dx || 0, +m.dy || 0) || 1; p.dx = (+m.dx || 0) / dl; p.dy = (+m.dy || 0) / dl;
  p.face = m.f < 0 ? -1 : 1; p.moving = m.m ? 1 : 0;
}
function onRevive(p) {
  if (!p.dead) return;
  p.dead = false; p.hp = p.maxHp; p.gold = Math.floor(p.gold * .9); p.x = CX; p.y = CY + 70; p.inv = 2;
  priv(p, { k: 'pos', x: p.x, y: p.y, revive: 1 }); persist(p);
}
function onChat(p, m) {
  const now = Date.now(); if (now - p.chatT < 900) return; p.chatT = now;
  const msg = String(m.m || '').replace(/[\u0000-\u001f]/g, '').trim().slice(0, 80);
  if (!msg) return;
  ev({ k: 'ch', id: p.key, n: p.name, m: msg });
}
function handle(p, txt) {
  let m; try { m = JSON.parse(txt); } catch (e) { return; }
  if (!m || typeof m !== 'object') return;
  switch (m.t) {
    case 'mv': onMove(p, m); break;
    case 'atk': onAttack(p, m); break;
    case 'sk': onSkill(p, m); break;
    case 'rv': onRevive(p); break;
    case 'chat': onChat(p, m); break;
  }
}

/* ---------------- simulation ---------------- */
function pickTarget(e, aggro) {
  let best = null, bd = aggro;
  for (const p of players.values()) { if (p.dead || inSafe(p)) continue; const d = hyp(p.x - e.x, p.y - e.y); if (d < bd) { bd = d; best = p; } }
  return best;
}
function updateEnemy(e, dt) {
  const b = ET[e.type], K = e.kind; e.t += dt; e.flash -= dt; e.cd -= dt;
  if (e.spawn > 0) { e.spawn -= dt; return; }
  let P = e.tgt;
  if (P && (P.dead || !players.has(P.key) || inSafe(P) || hyp(P.x - e.x, P.y - e.y) > b.aggro * 2.6)) P = e.tgt = null;
  if (!P) { const np = pickTarget(e, b.aggro); if (np) { P = e.tgt = np; alertPack(e, np); } }
  let vx = 0, vy = 0;
  const dx = P ? P.x - e.x : 0, dy = P ? P.y - e.y : 0, d = P ? (hyp(dx, dy) || 1) : 1e9;
  if (e.wind > 0) {
    e.wind -= dt;
    if (e.wind <= 0) {
      if (e.slamming) {
        e.slamming = false; e.cd = K === 'treant' ? 1.8 : 1.2;
        ev({ k: 'sl', x: Math.round(e.x), y: Math.round(e.y), big: e.big ? 1 : 0 });
        for (const p of players.values()) if (hyp(p.x - e.x, p.y - e.y) < e.slamR + p.r) hurtPlayer(p, e.dmg * (e.big ? 1.3 : 1), e);
      } else if (P) {
        const sp = K === 'boar' ? (e.big ? 390 : 360) : 250;
        e.dash = K === 'boar' ? (e.big ? .7 : .55) : .2; e.dvx = dx / d * sp; e.dvy = dy / d * sp; e.hit = false;
      }
    }
  } else if (e.dash > 0) {
    e.dash -= dt; vx = e.dvx; vy = e.dvy;
    if (!e.hit) for (const p of players.values()) if (!p.dead && hyp(p.x - e.x, p.y - e.y) < e.r + p.r + 8) { hurtPlayer(p, e.dmg, e); e.hit = true; break; }
    if (e.dash <= 0) e.cd = K === 'slime' ? 1.2 : K === 'shroom' ? 1.3 : e.big ? 1.4 : 1.8;
  } else if (P) {
    if (Math.abs(dx) > 4) e.face = dx > 0 ? 1 : -1;
    if (e.big) e.slam -= dt;
    const range = K === 'boar' ? (e.big ? 210 : 190) : K === 'treant' ? e.r + 48 : 44 + e.r;
    if (e.cd <= 0 && d < range) {
      if (e.big && e.slam <= 0 && d < 150) { e.slamming = true; e.slamR = 130; e.wind = .95; e.slam = 5.5; ev({ k: 'tl', x: Math.round(e.x), y: Math.round(e.y), r: 130, d: .95 }); }
      else if (K === 'treant') { e.slamming = true; e.slamR = 72; e.wind = .75; ev({ k: 'tl', x: Math.round(e.x), y: Math.round(e.y), r: 72, d: .75 }); }
      else e.wind = K === 'slime' ? .38 : K === 'shroom' ? .42 : e.big ? .65 : .6;
    } else if (d > e.r + P.r + 4) { let sp = b.spd; if (K === 'slime') sp *= Math.max(0, Math.sin(e.t * 7)) * 1.9; vx = dx / d * sp; vy = dy / d * sp; }
  } else {
    e.wt -= dt;
    if (e.wt <= 0) {
      e.wt = 1.5 + rnd() * 2.5; const hd = hyp(e.hx - e.x, e.hy - e.y);
      if (hd > (e.pack ? 90 : 160)) { e.wx = (e.hx - e.x) / hd * b.spd * .5; e.wy = (e.hy - e.y) / hd * b.spd * .5; }
      else if (rnd() < .55) { const a = rnd() * TAU; e.wx = Math.cos(a) * b.spd * .4; e.wy = Math.sin(a) * b.spd * .4; }
      else e.wx = e.wy = 0;
      if (Math.abs(e.wx) > 1) e.face = e.wx > 0 ? 1 : -1;
    }
    vx = e.wx; vy = e.wy; if (K === 'slime') { const h = Math.max(0, Math.sin(e.t * 6)) * 1.8; vx *= h; vy *= h; }
    if (e.hp < e.max) e.hp = Math.min(e.max, e.hp + e.max * (e.big ? .02 : .05) * dt);
    if (e.contrib.size && e.hp >= e.max) e.contrib.clear();
  }
  e.x += (vx + e.kx) * dt; e.y += (vy + e.ky) * dt; const dec = Math.pow(.002, dt); e.kx *= dec; e.ky *= dec;
  collideEnt(e);
  const sd = hyp(e.x - CX, e.y - CY); if (sd < SAFE) { e.x = CX + (e.x - CX) / sd * SAFE; e.y = CY + (e.y - CY) / sd * SAFE; if (e.dash > 0) e.dash = 0; }
}
function updatePlayers(dt) {
  for (const p of players.values()) {
    for (const k in p.cd) p.cd[k] = Math.max(0, p.cd[k] - dt);
    p.inv -= dt;
    if (p.dead) continue;
    if (p.spin > 0) {
      p.spin -= dt; p.spinTick -= dt;
      if (p.spinTick <= 0) { p.spinTick = .14; for (const e of enemies) { const dx = e.x - p.x, dy = e.y - p.y, d = hyp(dx, dy) || 1; if (d < 92 + e.r) hurtEnemy(e, p.atk * .75, dx / d, dy / d, 160, p); } }
    }
    if (time - p.lastHurt > 5) p.hp = Math.min(p.maxHp, p.hp + (1 + p.maxHp * .01) * dt);
    if (hyp(p.x - CX, p.y - CY) < 95) p.hp = Math.min(p.maxHp, p.hp + p.maxHp * .25 * dt);
  }
}
function packSummary() {
  for (const p of packs) { p._n = 0; p._x = 0; p._y = 0; }
  for (const e of enemies) if (e.pack) { e.pack._n++; e.pack._x += e.x; e.pack._y += e.y; }
  return packs.map(p => [TI[p.type], p.lo, p.hi, Math.round(p._n ? p._x / p._n : p.x), Math.round(p._n ? p._y / p._n : p.y), p._n]);
}

let tickN = 0;
function tick() {
  const dt = TICK / 1000; time += dt; tickN++;
  updatePlayers(dt);
  for (const e of enemies) updateEnemy(e, dt);
  for (let i = 0; i < enemies.length; i++) {
    const a = enemies[i];
    for (let j = i + 1; j < enemies.length; j++) {
      const b = enemies[j], dx = b.x - a.x, dy = b.y - a.y; if (Math.abs(dx) > 90 || Math.abs(dy) > 90) continue;
      const d = hyp(dx, dy) || 1, m = a.r + b.r; if (d < m) { const q = (m - d) / 2; a.x -= dx / d * q; a.y -= dy / d * q; b.x += dx / d * q; b.y += dy / d * q; }
    }
  }
  for (let i = enemies.length - 1; i >= 0; i--) if (enemies[i].hp <= 0) enemies.splice(i, 1);
  if (boss.hp <= 0 && Date.now() >= (W.bossAt || 0)) { boss = mkEnemy('boss', BOSS_POS.x, BOSS_POS.y, 20, null); boss.spawn = .8; enemies.push(boss); ev({ k: 'bs', x: boss.x, y: boss.y }); }
  for (let i = respawnQ.length - 1; i >= 0; i--) {
    const q = respawnQ[i]; q.t -= dt; if (q.t > 0) continue;
    const p = q.p, b = ET[q.type]; let ex = p.x, ey = p.y, ok = false;
    for (let t = 0; t < 12; t++) { const a = rnd() * TAU, r = 15 + rnd() * 60; ex = p.x + Math.cos(a) * r; ey = p.y + Math.sin(a) * r; if (!blocked(ex, ey, b.r)) { ok = true; break; } }
    if (!ok || nearPlayer(ex, ey, 70)) { q.t = .6; continue; }
    const lv = clamp(p.lo + Math.round(rnd() * (p.hi - p.lo)), b.lv[0], b.lv[1]);
    const e = mkEnemy(q.type, ex, ey, lv, p); e.spawn = .5; e.cd = 1.2; enemies.push(e);
    ev({ k: 'rs', x: Math.round(ex), y: Math.round(ey) });
    respawnQ.splice(i, 1);
  }
  for (let i = projs.length - 1; i >= 0; i--) {
    const p = projs[i]; p.x += p.vx * dt; p.y += p.vy * dt; p.life -= dt;
    let boom = p.life <= 0 || blocked(p.x, p.y + 16, 3);
    if (!boom) for (const e of enemies) { if (e.spawn <= 0 && hyp(e.x - p.x, (e.y - e.r) - p.y) < e.r + 10) { boom = true; break; } }
    if (boom) {
      for (const e of enemies) { const dx = e.x - p.x, dy = (e.y - e.r) - p.y, d = hyp(dx, dy) || 1; if (d < 62 + e.r) hurtEnemy(e, p.dmg * (d < e.r + 12 ? 1 : .6), dx / d, dy / d, 260, players.get(p.owner.key) === p.owner ? p.owner : null); }
      ev({ k: 'bm', x: Math.round(p.x), y: Math.round(p.y) }); projs.splice(i, 1);
    }
  }
  broadcast();
}

function broadcast() {
  const all = [...players.values()];
  const plist = all.map(p => [p.key, p.name, Math.round(p.x), Math.round(p.y), p.face, +p.dx.toFixed(2), +p.dy.toFixed(2), p.moving, p.lvl, Math.ceil(p.hp), p.maxHp, p.spin > 0 ? 1 : 0, p.dead ? 1 : 0]);
  const bossInfo = [boss.hp > 0 ? 1 : 0, Math.round(boss.x), Math.round(boss.y), Math.ceil(Math.max(0, boss.hp)), boss.max, W.bossAt || 0];
  const pk = tickN % 40 === 0 ? packSummary() : null;
  for (const p of all) {
    const en = [];
    for (const e of enemies) {
      if (!e.big && (Math.abs(e.x - p.x) > VIEW || Math.abs(e.y - p.y) > VIEW)) continue;
      const fl = (e.tgt ? 1 : 0) | (e.wind > 0 ? 2 : 0) | (e.dash > 0 ? 4 : 0) | (e.slamming ? 8 : 0) | (e.spawn > 0 ? 16 : 0) | (Math.abs(e.wx) + Math.abs(e.wy) > 1 ? 32 : 0);
      en.push([e.id, TI[e.type], Math.round(e.x), Math.round(e.y), Math.ceil(e.hp), e.max, e.lv, e.face, fl]);
    }
    const evs = [];
    for (const e of events) { if (e.x === undefined || (Math.abs(e.x - p.x) < VIEW + 200 && Math.abs(e.y - p.y) < VIEW + 200)) evs.push(e); }
    for (const e of p.q) evs.push(e); p.q.length = 0;
    const msg = { t: 's', y: [Math.ceil(p.hp), p.maxHp, p.lvl, p.xp, p.gold, p.pot, p.atk, p.def, p.dead ? 1 : 0], p: plist, e: en, b: bossInfo };
    if (evs.length) msg.ev = evs;
    if (pk) msg.pk = pk;
    send(p, msg);
  }
  events = [];
}

let timer = null;
function start() { if (!timer) timer = setInterval(tick, TICK); }
function saveAll() { for (const p of players.values()) persist(p); }
function online() { return players.size; }

module.exports = { start, addPlayer, removePlayer, handle, saveAll, online, _test: { tick, players, enemies } };
