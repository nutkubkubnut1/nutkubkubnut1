'use strict';
// Tiny JSON-file database: accounts, login tokens, character saves, world state.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DIR = process.env.DATA_DIR || process.env.RAILWAY_VOLUME_MOUNT_PATH || path.join(__dirname, '..', 'data');
fs.mkdirSync(DIR, { recursive: true });
const FILE = path.join(DIR, 'db.json');

let data = { users: {}, tokens: {}, world: {} };
try { data = JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch (e) { /* first run */ }
data.users = data.users || {}; data.tokens = data.tokens || {}; data.world = data.world || {};
for (const [t, r] of Object.entries(data.tokens)) if (!r || r.exp < Date.now()) delete data.tokens[t];

let dirty = true;
function markDirty() { dirty = true; }
function flush() {
  if (!dirty) return;
  dirty = false;
  const tmp = FILE + '.tmp';
  try { fs.writeFileSync(tmp, JSON.stringify(data)); fs.renameSync(tmp, FILE); }
  catch (e) { console.error('DB write failed', e); dirty = true; }
}
setInterval(flush, 3000).unref();

const ID_RE = /^[A-Za-z0-9_฀-๿]{3,16}$/;
const keyOf = id => String(id).trim().toLowerCase();

function scrypt(pw, salt) {
  return new Promise((res, rej) => crypto.scrypt(pw, salt, 32, { N: 16384, r: 8, p: 1 }, (e, k) => e ? rej(e) : res(k)));
}
function newSave() { return { lvl: 1, xp: 0, gold: 0, pot: 3 }; }

async function register(id, pw) {
  id = String(id || '').trim(); pw = String(pw || '');
  if (!ID_RE.test(id)) return { err: 'ID ต้องยาว 3–16 ตัว ใช้ได้ ก-ฮ, A-Z, 0-9, _' };
  if (pw.length < 6 || pw.length > 64) return { err: 'รหัสผ่านต้องยาว 6–64 ตัวอักษร' };
  const k = keyOf(id);
  if (data.users[k]) return { err: 'ID นี้มีคนใช้แล้ว' };
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = (await scrypt(pw, salt)).toString('hex');
  if (data.users[k]) return { err: 'ID นี้มีคนใช้แล้ว' };
  data.users[k] = { name: id, salt, hash, created: Date.now(), save: newSave() };
  markDirty();
  return { ok: true, token: newToken(k), name: id };
}

async function login(id, pw) {
  const k = keyOf(id || '');
  const u = data.users[k];
  // always run scrypt so timing does not reveal whether the ID exists
  const salt = u ? u.salt : 'x'.repeat(32);
  const h = await scrypt(String(pw || ''), salt);
  if (!u) return { err: 'ID หรือรหัสผ่านไม่ถูกต้อง' };
  const ok = crypto.timingSafeEqual(h, Buffer.from(u.hash, 'hex'));
  if (!ok) return { err: 'ID หรือรหัสผ่านไม่ถูกต้อง' };
  u.lastLogin = Date.now(); markDirty();
  return { ok: true, token: newToken(k), name: u.name };
}

function newToken(k) {
  const t = crypto.randomBytes(24).toString('hex');
  data.tokens[t] = { u: k, exp: Date.now() + 30 * 864e5 };
  markDirty();
  return t;
}
function userByToken(t) {
  if (typeof t !== 'string') return null;
  const r = data.tokens[t];
  if (!r) return null;
  if (r.exp < Date.now()) { delete data.tokens[t]; markDirty(); return null; }
  return data.users[r.u] ? r.u : null;
}
function revoke(t) { if (data.tokens[t]) { delete data.tokens[t]; markDirty(); } }
function getUser(k) { return data.users[k]; }
function world() { return data.world; }

module.exports = { register, login, userByToken, revoke, getUser, world, markDirty, flush, DIR };
