/* ดาบแห่งป่าลึก — shared world (used by browser + server) */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.SHARED=factory()})(typeof self!=='undefined'?self:this,function(){
'use strict';
const TAU=Math.PI*2, hyp=Math.hypot;
const clamp=(v,a,b)=>v<a?a:v>b?b:v, lerp=(a,b,t)=>a+(b-a)*t;
function mulberry(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const R=mulberry(20261106);
/* ================= WORLD GEN ================= */
const N=64,T=40,WORLD=N*T,CX=WORLD/2,CY=WORLD/2,SAFE=8*T;
const dirt=new Uint8Array(N*N);
const di=(x,y)=>(x<0||y<0||x>=N||y>=N)?0:dirt[y*N+x];
function carve(cx,cy,rad){for(let y=Math.floor(cy-rad);y<=cy+rad;y++)for(let x=Math.floor(cx-rad);x<=cx+rad;x++){if(x<0||y<0||x>=N||y>=N)continue;if(hyp(x+.5-cx,y+.5-cy)<=rad)dirt[y*N+x]=1}}
carve(N/2,N/2,5.6);
for(let k=0;k<6;k++){let a=k*TAU/6+R()*.6,x=N/2,y=N/2;for(let s=0;s<70;s++){a+=(R()-.5)*.5;x+=Math.cos(a)*.9;y+=Math.sin(a)*.9;if(x<3||y<3||x>N-3||y>N-3)break;carve(x,y,1.1+R()*.7)}}
const BOSS_T={x:N-9,y:9};
carve(BOSS_T.x,BOSS_T.y,4.5);
{let x=N/2,y=N/2;for(let s=0;s<200;s++){const a=Math.atan2(BOSS_T.y-y,BOSS_T.x-x)+(R()-.5)*1.1;x+=Math.cos(a)*.8;y+=Math.sin(a)*.8;carve(x,y,1.2);if(hyp(x-BOSS_T.x,y-BOSS_T.y)<2)break}}
for(let k=0;k<34;k++)carve(3+R()*(N-6),3+R()*(N-6),1.1+R()*1.9);
const BOSS_POS={x:(BOSS_T.x+.5)*T,y:(BOSS_T.y+.5)*T};

// colliders grid
const CELL=80,GN=Math.ceil(WORLD/CELL),grid=[];for(let i=0;i<GN*GN;i++)grid.push([]);
function addCol(x,y,r){const o={x,y,r};const x0=Math.max(0,Math.floor((x-r)/CELL)),x1=Math.min(GN-1,Math.floor((x+r)/CELL)),y0=Math.max(0,Math.floor((y-r)/CELL)),y1=Math.min(GN-1,Math.floor((y+r)/CELL));for(let gy=y0;gy<=y1;gy++)for(let gx=x0;gx<=x1;gx++)grid[gy*GN+gx].push(o);return o}
function nearCols(x,y,fn){const gx=Math.floor(x/CELL),gy=Math.floor(y/CELL);for(let j=-1;j<=1;j++)for(let i=-1;i<=1;i++){const X=gx+i,Y=gy+j;if(X<0||Y<0||X>=GN||Y>=GN)continue;const c=grid[Y*GN+X];for(let k=0;k<c.length;k++)fn(c[k])}}
function blocked(x,y,r){if(x<T||y<T||x>WORLD-T||y>WORLD-T)return true;let b=false;nearCols(x,y,o=>{if(!b&&hyp(x-o.x,y-o.y)<r+o.r)b=true});return b}
function collideEnt(e){
  nearCols(e.x,e.y,o=>{const dx=e.x-o.x,dy=e.y-o.y,d=hyp(dx,dy),m=e.r+o.r;if(d<m&&d>0.001){e.x=o.x+dx/d*m;e.y=o.y+dy/d*m}});
  e.x=clamp(e.x,T*.8,WORLD-T*.8);e.y=clamp(e.y,T*.8,WORLD-T*.8);
}


/* ---- props ---- */
const props=[];
props.push({k:'crystal',x:CX,y:CY-6});addCol(CX,CY-6,16);
// fences
for(let f=0;f<16;f++){
  let x,y,tries=0;do{x=T*3+R()*(WORLD-6*T);y=T*3+R()*(WORLD-6*T);tries++}while(tries<50&&(di(x/T|0,y/T|0)||hyp(x-CX,y-CY)<SAFE-60||hyp(x-BOSS_POS.x,y-BOSS_POS.y)<220));
  const horiz=R()<.6,n=4+(R()*5|0);let prev=null;
  for(let i=0;i<n;i++){const px=x+(horiz?i*26:0),py=y+(horiz?0:i*26);if(di(px/T|0,py/T|0)||blocked(px,py,6)){prev=null;continue}
    const p={k:'post',x:px,y:py,next:null};if(prev)prev.next=p;props.push(p);addCol(px,py,7);prev=p}
}
// fence ring at village edge (decor, with gaps)
for(let i=0;i<64;i++){const a=i/64*TAU;if(i%8<3)continue;const px=CX+Math.cos(a)*(SAFE-30),py=CY+Math.sin(a)*(SAFE-30);if(di(px/T|0,py/T|0))continue;props.push({k:'post',x:px,y:py,next:null});addCol(px,py,7)}
for(let i=0;i<props.length-1;i++){const a=props[i],b=props[i+1];if(a.k==='post'&&b.k==='post'&&!a.next&&hyp(a.x-b.x,a.y-b.y)<32)a.next=b}
// trees
let nt=0;
for(let i=0;i<4200&&nt<640;i++){
  const x=T+R()*(WORLD-2*T),y=T+R()*(WORLD-2*T),tx=x/T|0,ty=y/T|0;
  if(di(tx,ty)||di(tx+1,ty)||di(tx-1,ty)||di(tx,ty+1)||di(tx,ty-1))continue;
  const d=hyp(x-CX,y-CY);if(d<SAFE+30)continue;
  const edge=Math.min(x,y,WORLD-x,WORLD-y);
  const p=edge<170?.95:.2+.3*(d/(WORLD*.7));
  if(R()>p)continue;
  const bush=R()<.2;
  if(blocked(x,y-4,bush?24:32))continue;
  props.push({k:bush?'bush':'tree',x,y,v:R()*3|0,sc:.85+R()*.35});addCol(x,y-4,bush?16:13);nt++;
}
for(let i=0;i<90;i++){const x=T+R()*(WORLD-2*T),y=T+R()*(WORLD-2*T);if(hyp(x-CX,y-CY)<SAFE)continue;const sc=.7+R()*.6;if(blocked(x,y-6,20*sc+6))continue;props.push({k:'rock',x,y,v:R()*2|0,sc});addCol(x,y-6,15*sc)}


const walk=new Uint8Array(N*N);
for(let y=0;y<N;y++)for(let x=0;x<N;x++)walk[y*N+x]=(x<1||y<1||x>=N-1||y>=N-1||blocked(x*T+T/2,y*T+T/2,9))?0:1;
const prevA=new Int32Array(N*N);
function findPath(sx,sy,tx,ty){
  const s0=clamp(sy/T|0,0,N-1)*N+clamp(sx/T|0,0,N-1),t0=clamp(ty/T|0,0,N-1)*N+clamp(tx/T|0,0,N-1);
  if(s0===t0)return[{x:tx,y:ty}];
  prevA.fill(-1);prevA[s0]=s0;const q=[s0];let h=0,found=false;
  while(h<q.length){const c=q[h++];if(c===t0){found=true;break}const cx=c%N,cy=c/N|0;
    const nb=[cx>0?c-1:-1,cx<N-1?c+1:-1,cy>0?c-N:-1,cy<N-1?c+N:-1];
    for(const n of nb){if(n<0||prevA[n]!==-1)continue;if(!walk[n]&&n!==t0)continue;prevA[n]=c;q.push(n)}}
  if(!found)return null;
  const path=[];let c=t0;while(c!==s0){path.push({x:(c%N)*T+T/2,y:(c/N|0)*T+T/2});c=prevA[c]}
  path.reverse();path[path.length-1]={x:tx,y:ty};return path;
}

const ET={
  slime:{kind:'slime',name:'สไลม์',lv:[1,3],hp:.8,dmg:.8,spd:55,r:14,aggro:160,pal:['#c8ff9e','#4fae3a'],dot:'#9dff6a'},
  wslime:{kind:'slime',name:'สไลม์น้ำ',lv:[3,6],hp:.9,dmg:.9,spd:62,r:15,aggro:170,pal:['#d2f2ff','#2f86d0'],dot:'#6ac8ff'},
  shroom:{kind:'shroom',name:'เห็ดพิษ',lv:[5,9],hp:1,dmg:1,spd:62,r:15,aggro:190,pal:['#d9472f','#fff3e0','#f1e4c6'],dot:'#ff7a5a'},
  pshroom:{kind:'shroom',name:'เห็ดราตี',lv:[8,12],hp:1.1,dmg:1.1,spd:66,r:16,aggro:200,pal:['#7c46c4','#d8ff7a','#e6dcc8'],dot:'#c08aff'},
  boar:{kind:'boar',name:'หมูป่า',lv:[11,15],hp:1.2,dmg:1.05,spd:78,r:20,aggro:230,pal:['#a06a42','#6a4428','#3e2616','#8e5c38'],dot:'#ffc06a'},
  treant:{kind:'treant',name:'ตอไม้ผี',lv:[14,18],hp:1.6,dmg:1.2,spd:44,r:20,aggro:210,pal:['#8a6038','#4e3420','#5fae45'],dot:'#b8e070'},
  dboar:{kind:'boar',name:'หมูป่าดำ',lv:[17,20],hp:1.35,dmg:1.2,spd:84,r:21,aggro:250,pal:['#5e5868','#2c2834','#16131c','#4a4552'],dot:'#d0d0e0'},
  boss:{kind:'boar',big:true,name:'ราชาหมูป่า',lv:[20,20],hp:12,dmg:1.6,spd:82,r:40,aggro:330,pal:['#8a5fa6','#4e3460','#2e1d38','#7a5296'],dot:'#ff40ff'}
};
const MON_ORDER=['slime','wslime','shroom','pshroom','boar','treant','dboar','boss'];
const ZONES=[{n:'ทุ่งสไลม์',a:1,b:5},{n:'ป่าเห็ด',a:6,b:10},{n:'ป่าลึก',a:11,b:15},{n:'ป่ามืด',a:16,b:20}];
const D0=SAFE+40,D1=1300;
const lvAt=d=>clamp(Math.round(1+(d-D0)/(D1-D0)*19),1,20);
const dAt=lv=>D0+(lv-1)/19*(D1-D0);
const xpNeed=l=>Math.round(25*Math.pow(l,1.6));
function stats(l){return{maxHp:100+22*(l-1),atk:12+4*(l-1),def:Math.floor((l-1)*1.5)}}
const CD={fire:2.2,whirl:6,heal:12,pot:1.5};
const SPEED=165, BOSS_CD=300000;
const inSafe=(o)=>hyp(o.x-CX,o.y-CY)<SAFE-20;
return {TAU,hyp,clamp,lerp,mulberry,N,T,WORLD,CX,CY,SAFE,dirt,di,BOSS_T,BOSS_POS,CELL,GN,grid,nearCols,blocked,collideEnt,props,walk,findPath,
  ET,MON_ORDER,ZONES,D0,D1,lvAt,dAt,xpNeed,stats,CD,SPEED,BOSS_CD,inSafe};
});
